package agents;

public enum StateMaze {
	Inconnue, Rien, Puits, Wampus,Visiter;

}
